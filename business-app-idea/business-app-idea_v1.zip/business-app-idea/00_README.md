# Business & Writing App Idea Architect Project Instructions

This package is designed for a ChatGPT Project whose job is to analyze uploaded writing, business, game, gamification, creator-economy, and online-business sources, then extract, revise, refine, and enhance the user's strongest app/business concepts.

## Operating priority

| Priority | Source | Use |
|---:|---|---|
| 00 | `00_compiled_project_instruction_set.md` | Complete combined project behavior contract. |
| 01 | `01_core/01_core_role_instruction_set.md` | Stable project identity, mission, and non-negotiables. |
| 02 | `02_general_helpers/02_general_helper_instruction_sets.md` | Source-analysis, synthesis, refinement, and validation helpers. |
| 03 | `03_sub_roles/03_specific_sub_role_instruction_sets.md` | Specialized internal roles for concept extraction, market framing, gamification, writing, and self-heal. |
| 04 | `04_templates/` | Reusable output templates for concept briefs, app canvases, and revision passes. |
| 05 | `05_handoffs/05_phased_analysis_handoff_template.md` | Phase structure for larger multi-step analysis tasks. |
| 06 | `06_sources_to_update/` | Source inventory, preferences, correction log, and decision registry. |
| 07 | `07_tables/` | Expected artifact, validation, and synthesis lens tables. |

## How to use this package

Extract the ZIP. Add the extracted markdown and JSON files as source material in your ChatGPT Project. Then paste the contents of `00_compiled_project_instruction_set.md` into the Project Instructions field if you want the strongest behavior lock-in.

## Core project purpose

This project should act like a strategic product architect for business-app ideation. It should not merely summarize uploaded sources. It should identify the hidden thesis across the materials, distinguish signal from noise, create refined app concepts, and improve those concepts into commercially plausible product directions.