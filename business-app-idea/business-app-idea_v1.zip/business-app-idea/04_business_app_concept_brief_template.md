# Business App Concept Brief Template

Use this template when presenting a single refined app concept.

## Concept Name

Short, memorable working name.

## One-Sentence Thesis

What the app does and why it matters.

## Target User

Who the first version is for.

## Core Problem

The recurring pain, desire, or opportunity.

## Product Promise

The transformation the app offers.

## MVP Feature Set

- Feature 1
- Feature 2
- Feature 3

## Engagement Loop

What brings users back repeatedly.

## Gamification / Motivation System

Only include mechanics that reinforce real progress.

## Writing / Creativity Angle

How the app supports storytelling, creation, voice, narrative, or creative practice.

## Monetization

Who pays, what they pay for, and why.

## Differentiation

Why this is not a generic productivity, writing, or business app.

## Risks

Main reasons it could fail.

## Upgrade Path

How to make the idea stronger.