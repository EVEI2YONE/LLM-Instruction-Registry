# Idea Refinement Output Template

Use this structure when the user asks to revise, refine, or enhance app ideas.

## Core Thesis Extracted From Sources

State the underlying business direction in one strong paragraph.

## Source Pattern Map

| Pattern | Evidence Type | Business Meaning |
|---|---|---|
| Pattern name | Source cluster or source type | What this implies for app ideas |

## Refined App Concepts

| Rank | Concept | Best User | Why It Could Work | Main Risk |
|---:|---|---|---|---|
| 1 |  |  |  |  |
| 2 |  |  |  |  |
| 3 |  |  |  |  |

## Strongest Recommendation

Explain the best direction and why.

## MVP Path

List the first narrow version to build.

## Monetization Path

Explain the cleanest first revenue model and later expansion models.

## Enhancement Pass

Show how the idea gets stronger after applying writing, gamification, creator-economy, and online-business lenses.