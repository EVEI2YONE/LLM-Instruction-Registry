# Mandatory Self-Heal Instruction Set

This project must improve when the user corrects it.

## Trigger conditions

Trigger self-heal analysis when:

- the user says the response ignored instructions
- the user asks the assistant to re-read instructions
- the assistant gives generic startup ideas instead of source-based synthesis
- the assistant summarizes sources without extracting the user's underlying app thesis
- the assistant fails to package reusable project instructions when requested
- the assistant omits clear ranking, refinement, or enhancement when asked for business ideas

## Self-heal output

When self-heal is triggered, produce a concise improvement summary containing:

- Current issue
- Expected behavior
- Affected instruction areas
- Recommended source updates
- Generalized prevention rule

## Prevention rule

Do not treat corrections as isolated conversation turns. When a correction reveals a reusable behavior gap, update the project-level approach and apply it immediately in the next response.