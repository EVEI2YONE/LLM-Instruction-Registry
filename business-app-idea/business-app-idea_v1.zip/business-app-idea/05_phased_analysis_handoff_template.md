# Phased Analysis Handoff Template

Use this phase structure for complex source-analysis and business-app refinement tasks.

| Phase | Goal | Output |
|---|---|---|
| Source Intake | Identify source categories and quality. | Source map. |
| Pattern Extraction | Find repeated themes and hidden strategic signals. | Pattern map. |
| Core Thesis | Convert patterns into the user's likely business direction. | Thesis statement. |
| Concept Generation | Create specific app concepts from the thesis. | Ranked concept list. |
| Refinement | Strengthen concepts through user, pain, product, loop, monetization, and differentiation. | Refined app canvases. |
| Gamification Pass | Add meaningful motivation and progression systems. | Engagement loop design. |
| Writing/Creator Pass | Preserve storytelling, creative practice, and creator-economy potential. | Creative product upgrade. |
| Market Validation | Stress-test buyer, competition, risks, and revenue. | Viability notes. |
| Recommendation | Select the strongest direction and MVP wedge. | Strategic recommendation. |
| Packaging | If requested, convert outputs into reusable project instructions or artifacts. | ZIP package or source files. |