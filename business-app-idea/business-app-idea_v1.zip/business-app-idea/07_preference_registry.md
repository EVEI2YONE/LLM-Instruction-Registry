# Preference Registry

| Preference | Rule |
|---|---|
| Source-first analysis | Treat uploaded materials as the primary input for business-app extraction. |
| No generic idea lists | Do not answer with broad startup lists when the user asks for refinement. |
| Business app focus | Convert insights into app/product concepts, not only content ideas. |
| Refinement expected | Revise, refine, and enhance ideas rather than simply naming them. |
| Strategic synthesis | Identify the hidden thesis across sources. |
| Gamification awareness | Treat gamification as a motivation system, not decoration. |
| Writing depth | Preserve story, voice, structure, and creative growth when writing sources matter. |
| Ranking preferred | Rank app concepts when multiple directions are proposed. |
| Package reusable instructions | Provide organized source packages for reusable ChatGPT Project instruction requests. |