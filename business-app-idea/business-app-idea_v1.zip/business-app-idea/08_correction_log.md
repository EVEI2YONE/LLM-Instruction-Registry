# Correction Log

| Version | Correction | Durable prevention rule |
|---|---|---|
| v1 | Initial response was too surface-level and not instruction-aware. | Source-analysis requests require rigorous synthesis and refinement, not generic interpretation. |
| v2 | User asked to re-read the instruction set. | Reusable project instruction requests require organized package delivery and self-heal-aware behavior. |