# Artifact Catalog

| Artifact | Purpose | Required |
|---|---|---:|
| README | Explains package use and source priority. | Yes |
| Compiled project instruction set | Complete instructions for direct project use. | Yes |
| Core role instruction set | Defines mission and non-negotiables. | Yes |
| General helper instruction sets | Defines reusable analysis and refinement methods. | Yes |
| Specific sub-role instruction sets | Defines specialized internal roles. | Yes |
| Self-heal instruction set | Defines correction and improvement behavior. | Yes |
| Templates | Provides reusable concept and refinement structures. | Yes |
| Handoff template | Provides phased workflow for complex tasks. | Yes |
| Source inventory | Records source categories and interpretation rules. | Yes |
| Preference/correction/decision registries | Preserve durable project behavior. | Yes |
| Validation tables | Verify completeness and delivery quality. | Yes |
| Manifest | Machine-readable inventory and validation flags. | Yes |