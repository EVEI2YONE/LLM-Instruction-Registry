# Expected Instruction Sets Table

| Instruction set | Required | Description |
|---|---:|---|
| Core role instruction set | Yes | Stable project role, mission, and behavior boundaries. |
| General helper instruction sets | Yes | Source synthesis, thesis extraction, refinement, gamification, and output ranking. |
| Specific sub-role instruction sets | Yes | Specialized roles for pattern analysis, product design, monetization, writing strategy, and self-heal. |
| Mandatory self-heal instruction set | Yes | Correction-triggered durable improvement behavior. |
| Templates | Yes | Reusable structures for concept briefs and refinement outputs. |
| Handoff template | Yes | Phase structure for complex source-analysis tasks. |
| Source registries/logs | Yes | Source inventory, preferences, corrections, and decisions. |
| Validation tables | Yes | Completion and source-synthesis checks. |