# Validation Table

| Check | Required | Status |
|---|---:|---:|
| ZIP package exists | Yes | Pass |
| README exists | Yes | Pass |
| Compiled instruction set exists | Yes | Pass |
| Core instruction set exists | Yes | Pass |
| Helper instruction set exists | Yes | Pass |
| Sub-role instruction set exists | Yes | Pass |
| Self-heal artifact exists | Yes | Pass |
| Templates exist | Yes | Pass |
| Source inventory exists | Yes | Pass |
| Manifest exists | Yes | Pass |
| Delivery response includes ZIP link | Yes | To verify at final response |
| Delivery response includes artifact table | Yes | To verify at final response |
| Delivery response includes extraction guidance | Yes | To verify at final response |