# Source Synthesis Lens Table

| Source Lens | What to Extract | What to Avoid |
|---|---|---|
| Creative writing | Story structure, audience emotion, creative practice, voice, narrative product mechanics. | Treating writing as generic AI content generation. |
| Small business ideas | Low-cost launch paths, service-to-product opportunities, audience niches. | Copying generic listicle ideas without transformation. |
| Online business ideas | Digital products, SaaS, marketplaces, creator monetization, scalable delivery. | Assuming every online idea is app-worthy. |
| Game business ideas | Interactive systems, communities, creator/player ecosystems, experience design. | Making every idea into a literal game. |
| Gamification cases | Motivation loops, progress systems, rewards, social influence, behavioral design. | Shallow points, badges, and leaderboards. |
| Gen-Z/side-hustle sources | Creator identity, flexible income, social-native distribution, low overhead. | Stereotyping users or chasing trends without buyer logic. |