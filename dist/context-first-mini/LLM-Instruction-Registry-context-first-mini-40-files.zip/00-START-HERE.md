# Context-first mini-registry
Snapshot generated 2026-11-09 from EVEI2YONE/LLM-Instruction-Registry@efb51d7e0ca9dcd4ece064ed7e94e4324c437206. Complete metadata index of 50 registered packages. This is a distribution artifact, not a new approved specialist release.

Mandatory order: understand intent; recover prior decisions and authoritative context; choose workflow and define in/out scope; identify dependencies and approvals; match packages by capabilities; pin repository SHA; retrieve each selected SKILL.md, manifest, read_when sections and requires closure; verify loaded instructions and authorization; only then execute. Missing mandatory instruction source = BLOCKED_INSTRUCTIONS. Metadata matching alone is never execution readiness.

Read 01-registry-index.json, 04-workflow-router.md, 05-scope-contract.md, 09-instruction-loading.md and 10-preflight-gate.md in that order. The 12 preserved orchestrator files remain normative for their own behavior.
