# Scope contract
Before route selection write: user goal, task/output, authorized decisions, in-scope, out-of-scope, constraints, assumptions, acceptance criteria, owner, dependencies, authorities, approval gates. Do not treat brainstorming as approved changes. Scope changes require reconciliation.
