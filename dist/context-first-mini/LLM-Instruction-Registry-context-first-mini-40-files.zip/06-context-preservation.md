# Context preservation
Persist versioned workflow/task IDs, source refs, provenance, earlier decisions, scope, instruction receipts, output references, blockers, approvals, status and next action. Do not assume chat history gives durable cross-session state; verify state artifact availability on resume.
