# Context-source index
1. Search conversation/project context and latest artifacts first.
2. Discover authoritative repositories and project docs.
3. Pin immutable source revisions and record freshness.
4. Use package index to identify 1–3 relevant candidates.
5. Load canonical SKILL.md plus required sections from GitHub before scoped work.
6. Identify missing or inaccessible sources without inventing instructions.

Canonical package source paths are in 01-registry-index.json.
