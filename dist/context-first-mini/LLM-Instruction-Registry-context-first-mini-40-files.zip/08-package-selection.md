# Package selection
Match exact ID, aliases, user intent, capability, domain and role. Compare candidates' actual purpose and boundaries; record rationale. Workflow coordinators and specialists have distinct responsibilities. Return no_matching_package on a verified miss; otherwise source_not_verified if inaccessible.
