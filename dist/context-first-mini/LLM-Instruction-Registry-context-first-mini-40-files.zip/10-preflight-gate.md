# Pre-execution gate
Mandatory order: understand intent; recover prior decisions and authoritative context; choose workflow and define in/out scope; identify dependencies and approvals; match packages by capabilities; pin repository SHA; retrieve each selected SKILL.md, manifest, read_when sections and requires closure; verify loaded instructions and authorization; only then execute. Missing mandatory instruction source = BLOCKED_INSTRUCTIONS. Metadata matching alone is never execution readiness.

PASS requires observable evidence for context, scope, instruction dependency closure and runtime authorization. Fail closed on missing source, contradictory approvals or unsupported tools. After work, independently verify instruction application and deliverable acceptance.
