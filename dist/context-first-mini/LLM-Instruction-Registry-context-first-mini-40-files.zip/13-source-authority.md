# Authority reconciliation
Task-specific project decisions and artifacts govern the product; registry instructions govern selected specialist behavior. Governance rules govern permissions and human approvals. Record origin, revision, date, trust boundary and conflicts. Inaccessible is not the same as absent. Escalate consequential contradictions.
