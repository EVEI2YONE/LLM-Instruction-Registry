# Runtime and approval
Probe callable native child, gateway and persistence tools; unknown is not available. If native child absent, run an explicitly parent-owned sequential specialist phase only with actual loaded instructions. No automated self-approval, merge, production release, investment or irreversible action.
