# Task dependency ledger
Record task ID, stage, owner, parents, prereqs, authority refs, package/version, loaded section IDs, requested versus actual tools, status, acceptance criteria, output evidence, review owner and next action. Block only dependent tasks when a merge or source is pending.
