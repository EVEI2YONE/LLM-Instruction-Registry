# Retrieval checks
Check full inventory coverage, unique IDs, valid source paths, matching capability/role, exact pinned SHA, read_when and requires closure, missing instructions, authority conflicts and existing decisions. Test exact ID, capability, ambiguous intents, stale refs and no-match queries. Lexical scores do not imply factual confidence.
