# Knowledge gap lookup
Determine missing versus stale versus inaccessible. Search existing catalog and PRs before creating changes. Gather evidence and prepare minimal reviewed catalog PR only when authorized. Block dependent work until merge and authoritative source refresh are independently verified.
