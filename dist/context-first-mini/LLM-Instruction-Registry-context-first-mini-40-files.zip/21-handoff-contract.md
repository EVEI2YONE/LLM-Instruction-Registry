# Handoff
Provide bounded objective, work IDs, in/out scope, project and registry revisions, decisions, instructions loaded, actual permissions, dependency status, approval owner, output refs, checks and next action. Never forward hidden reasoning, secrets or entire unrelated transcripts.
