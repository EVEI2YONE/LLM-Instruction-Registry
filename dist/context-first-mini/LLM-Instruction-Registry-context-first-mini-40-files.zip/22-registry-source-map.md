# Canonical registry map
Repository: https://github.com/EVEI2YONE/LLM-Instruction-Registry
Commit: efb51d7e0ca9dcd4ece064ed7e94e4324c437206
Paths: registry.json; docs/AGENTIC_SEARCH.md; docs/ROLE_TAXONOMY.md; docs/WORKFLOW_ARCHITECTURE.md; governance/approval.json; governance/common-rules.md; governance/capability-ownership/; runtime/ADAPTER_CONTRACT.md.

Use indexed sources per package and pin direct reads to the SHA.
