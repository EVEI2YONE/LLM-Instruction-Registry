# Index maintenance
Rebuild from pinned registry.json. Verify total count, unique IDs, source paths, ID/version/capability metadata, CSV parity and schema validity. Detect additions, changes, removals and status transitions. Do not hand-edit official registry entries or assume available means approved.
