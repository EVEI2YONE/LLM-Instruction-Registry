# Example searches
python3 27-search-local.py --id product-lifecycle-orchestrator
python3 27-search-local.py --capability context-reconciliation
python3 27-search-local.py --query "workflow"

Search gives candidates, not loaded executable instruction context.
