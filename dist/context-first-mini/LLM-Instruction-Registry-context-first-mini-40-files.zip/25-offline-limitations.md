# Offline limitations
All package metadata is indexed, but only Conversation Orchestrator's core sources are embedded. Other package SKILL.md, manifests and conditional sections must be fetched from the pinned registry before specialist work. The ZIP provides no native subagent facility, deployed worker, persistent storage, approval, or authoritative product decisions.
