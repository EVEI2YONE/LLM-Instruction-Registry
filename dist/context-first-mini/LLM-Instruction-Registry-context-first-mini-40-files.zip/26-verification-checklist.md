# Snapshot checks
- [ ] ZIP has exactly 40 root-level entries
- [ ] CRC test passes
- [ ] 50 package metadata records appear in JSON and CSV
- [ ] File names unique
- [ ] Both JSON schemas parse
- [ ] Search CLI exact ID, capability and no-match tests
- [ ] Preserved files match pinned source contents
- [ ] Instruction loading and behavioral runtime tests separately marked NOT_RUN unless observed
- [ ] PR is review-only; not merged
