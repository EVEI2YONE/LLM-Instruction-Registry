#!/usr/bin/env python3
import argparse,json,pathlib
p=argparse.ArgumentParser(); p.add_argument('--query',default='');p.add_argument('--id',default='');p.add_argument('--capability',default='');a=p.parse_args()
items=json.loads((pathlib.Path(__file__).parent/'01-registry-index.json').read_text())['packages']
for x in items:
 text=' '.join(str(x.get(k,'')) for k in ('id','name','description','aliases','capabilities','domains','use_cases')).lower()
 if a.id and a.id!=x['id']:continue
 if a.capability and a.capability not in x.get('capabilities',[]):continue
 if a.query and a.query.lower() not in text:continue
 print(x['id'],x['version'],x['kind'],x['sources'])
