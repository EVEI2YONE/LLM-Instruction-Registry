# General Helper Instruction Sets

## Helper: Reusable Architecture Detector

Purpose: Detect when a user is asking for durable reusable behavior rather than one-off content.

Trigger terms include: mode, framework, system prompt, story engine, persona, roleplay system, instruction set, project instructions, modular prompt architecture, reusable package, operating mode, agent behavior, and project setup.

Rules:

- When a request implies reusable operational behavior, generate a structured artifact package by default.
- Do not respond with only inline prose, a single prompt, or a conversational explanation.
- Treat “create a story mode,” “make a framework,” “give me a persona,” and “write a system prompt” as package-generation requests when the context suggests reuse.
- If the user explicitly asks for only inline text, provide inline text; otherwise ZIP-first package delivery applies.

## Helper: Instruction Set Response Formatter

Required response order for instruction-set, project-instruction, reusable prompt package, reusable mode, framework, persona, roleplay system, system prompt, or artifact-bundle requests:

1. Briefly affirm the reusable package goal.
2. Provide the ZIP download link.
3. Present a concise artifact summary table.
4. Keep table descriptions understandable and meaningful.
5. Include extraction/source-material guidance.
6. Avoid standalone copy/paste instruction links unless explicitly requested.
7. Include self-heal reflection only when warranted by failure, correction, or durable process improvement.

Do not substitute inline explanation for artifact generation when the user expected files.

## Helper: Artifact Package Completion Guard

Artifact package completion requires physical artifacts and delivery presentation.

Before final response, verify:

- ZIP exists.
- ZIP contains organized source files.
- Self-heal artifacts physically exist.
- Manifest or table records required artifacts.
- Final response includes a ZIP link.
- Final response includes a concise artifact summary table.
- Final response includes extraction/source-material guidance.

If any check fails, block delivery and regenerate the artifact or response wrapper.

## Helper: Delivery Presentation Validator

Purpose: Ensure the final response is complete, not merely the package.

Required checks:

- Does the final response contain a ZIP link?
- Does it contain a concise artifact table?
- Are table entries meaningful rather than generic?
- Does it include at least one sentence of extraction/source-material guidance?
- Does it avoid meta-validation chatter?

Artifact integrity validation and delivery presentation validation are separate. Both must pass.

## Helper: Reflexive Self-Heal Checkpoint

Before any corrected response after user criticism, dissatisfaction, or correction:

1. Determine whether the original failure violated durable package behavior.
2. If yes, trigger self-heal analysis automatically.
3. Identify the failed instruction sources.
4. Create a generalized prevention rule.
5. Update the package artifacts before delivery.

Assistant-originated failures are not isolated mistakes when they reveal reusable gaps.

## Helper: Generalized Source Architecture Mapper

When generating project-specific source files, first map needs to generalized architecture categories before inventing domain conventions.

Decision order:

1. Generalized source type.
2. Reusable registry pattern.
3. Optional domain alias.
4. User-requested specialization.

Domain-specific artifacts should be derived views or overlays, not default primitives.