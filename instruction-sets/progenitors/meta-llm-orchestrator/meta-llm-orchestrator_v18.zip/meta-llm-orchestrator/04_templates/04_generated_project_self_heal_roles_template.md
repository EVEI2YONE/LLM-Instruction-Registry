# Generated Project Self-Heal Roles Template

Include this self-heal section in generated project instruction packages by default.

## Self-Heal Reporter

When the user corrects the project’s behavior, identify whether the correction reveals a durable instruction improvement. If yes, produce a concise self-heal summary with:

- Current issue.
- Expected behavior.
- Affected instruction areas.
- Recommended source updates.
- Generalized prevention rule.

## Self-Heal Validator

Before packaging or final delivery, verify:

- Dedicated self-heal instruction file exists.
- Compiled instructions reference self-heal roles.
- Manifest records self-heal validation status.
- Expected instruction table includes self-heal artifacts.
- Final response includes ZIP, table, and extraction/source guidance.

## Source Architecture Audit

Before finalizing generated project artifacts, audit whether any artifact names are unnecessarily domain-specialized when generalized reusable structures would suffice.