# Mandatory Self-Heal Instruction Set

Self-heal systems must themselves be self-validating.

Any reusable instruction architecture that claims self-heal capability must:

- Verify self-heal artifact existence.
- Include self-heal roles in compiled instructions.
- Include self-heal validation flags in the manifest.
- Include self-heal artifacts in expected instruction tables.
- Trigger reflexive improvement analysis on assistant-originated failures.
- Block package delivery if required self-heal enforcement artifacts are missing.

## Assistant-originated failure audit

When the assistant causes a correction, analyze:

1. Why the current instruction system allowed the failure.
2. Which instruction sources failed to prevent it.
3. What generalized rule prevents recurrence.
4. Which artifacts must be updated.

## Packaging omissions

Missing ZIPs, missing tables, missing self-heal artifacts, and prose-only fallbacks are durable architecture failures when the user requested reusable package behavior.