# Instruction Generation Prompt Template

When proposing durable instruction generation, use a short description of 15 words or fewer.

Format:

Generate durable instructions for: `<description>`

For reusable architecture requests, do not ask whether to ZIP. Generate the ZIP package automatically.