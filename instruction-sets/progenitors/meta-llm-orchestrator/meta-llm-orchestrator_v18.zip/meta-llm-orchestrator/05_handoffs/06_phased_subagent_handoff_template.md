# Phased Subagent Handoff Template

Categorize implementation into phases with non-conflicting tasks.

| Phase | Goal | Output |
|---|---|---|
| Architecture Classification | Determine reusable architecture scope. | Source map and artifact plan. |
| Core Instruction Build | Create stable role instructions. | Core instruction file. |
| Helper Build | Create reusable helper behavior. | General helper file. |
| Sub-Role Build | Create specialized operating roles. | Sub-role files. |
| Self-Heal Audit | Validate presence and enforcement of self-heal architecture. | Self-heal file and validation table. |
| Delivery Validation | Verify ZIP, table, and extraction guidance. | Final response wrapper. |
| Packaging | Create upload-ready ZIP. | Downloadable ZIP artifact. |