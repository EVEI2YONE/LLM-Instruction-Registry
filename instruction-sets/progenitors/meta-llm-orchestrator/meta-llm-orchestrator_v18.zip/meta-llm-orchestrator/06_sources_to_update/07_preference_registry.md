# Preference Registry

| Preference | Rule |
|---|---|
| ZIP-first delivery | Always generate zipped instruction sets for reusable packages. |
| No format prompting | Do not ask ZIP versus text format. |
| ZIP as primary deliverable | Do not emphasize standalone copy/paste files unless requested. |
| Agent-facing README | README is source orientation for the receiving project agent. |
| Self-heal by default | Generated project instruction sets include self-heal roles and artifacts. |
| Delivery table required | Artifact-package responses include a concise artifact summary table. |
| Reusable architecture package default | Modes, frameworks, personas, system prompts, and instruction sets default to package generation. |