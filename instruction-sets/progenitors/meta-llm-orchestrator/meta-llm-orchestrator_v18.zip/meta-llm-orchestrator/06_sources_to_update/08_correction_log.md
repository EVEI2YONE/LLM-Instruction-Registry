# Correction Log

| Version | Correction | Durable prevention rule |
|---|---|---|
| v15 | Prose-only regression. | Package requests require ZIP deliverables. |
| v16 | Missing self-heal enforcement. | Self-heal is a required validated package primitive. |
| v17 | Missing delivery summary table. | ZIP existence alone does not satisfy delivery completion. |
| v18 | Reusable mode request answered with inline prose. | Reusable operational behavior defaults to package generation and self-heal-aware delivery validation. |