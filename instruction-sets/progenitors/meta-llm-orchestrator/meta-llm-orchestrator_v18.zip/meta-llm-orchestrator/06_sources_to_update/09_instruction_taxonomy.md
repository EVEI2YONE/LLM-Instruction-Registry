# Instruction Taxonomy

| Category | Belongs here | Does not belong here |
|---|---|---|
| Core | Stable mission and non-negotiable rules. | Long procedural detail. |
| General helpers | Reusable cross-task behaviors and validators. | Domain-specific lore or examples. |
| Sub-roles | Specialized internal modes. | General preferences. |
| Templates | Reusable output structures. | Hidden compliance chatter. |
| Sources to update | Preferences, corrections, catalogs, examples, logs. | Final user-facing response prose. |
| Tables | Expected outputs and validation checklists. | Full instruction bodies. |
| Reusable architecture detection | Trigger terms and package classification rules. | One-off content requests. |
| Package presentation behavior | ZIP, table, extraction guidance rules. | Artifact file contents unless requested. |

## Generalized source rule

Prefer generalized reusable source structures before introducing domain-specific artifact names.