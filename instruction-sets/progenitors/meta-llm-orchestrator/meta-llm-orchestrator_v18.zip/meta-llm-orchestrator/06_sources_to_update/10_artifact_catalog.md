# Artifact Catalog

| Artifact | Purpose | Required for packages? |
|---|---|---|
| ZIP package | Upload-ready bundle of all generated sources. | Yes |
| Artifact summary table | Chat-facing overview of included artifacts. | Yes |
| Extraction/source guidance | Tells user to extract and add files as source material. | Yes |
| Core instruction set | Stable role and mission behavior. | Yes |
| General helper instruction set | Reusable helper behavior. | Yes |
| Sub-role instruction set | Specialized operating roles. | Yes |
| Dedicated self-heal instruction set | Enforces reflexive improvement and validation. | Yes |
| Manifest | Machine-readable inventory and validation flags. | Yes |
| Validation table | Records package and delivery checks. | Yes |
| Generalized registry | Continuity, entity, context, preference, or decision registry. | When relevant |
| Domain overlay | Optional domain-specific view over generalized sources. | No, unless requested |