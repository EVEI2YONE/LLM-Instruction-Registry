# Source Inventory

This package contains core instructions, general helpers, sub-roles, self-heal artifacts, templates, handoffs, self-correcting sources, validation tables, and a manifest.