# Example Bank

## Correct reusable architecture handling

User asks: “Create a story mode for my project.”

Correct response behavior:

- Treat as reusable operational behavior.
- Generate modular instruction artifacts.
- ZIP the package.
- Include a summary table and extraction guidance.
- Include self-heal artifacts.

Incorrect response behavior:

- Only write inline prose.
- Only provide a single system prompt.
- Ask whether the user wants ZIP or text.
- Omit the artifact summary table.