# Unresolved Questions

No unresolved blocking questions for v18.