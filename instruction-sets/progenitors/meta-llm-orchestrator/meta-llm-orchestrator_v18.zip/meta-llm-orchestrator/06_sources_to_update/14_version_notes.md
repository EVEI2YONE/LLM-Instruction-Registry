# Version Notes

## v18

Adds explicit reusable-mode detection and single-file fallback prevention. Requests for modes, frameworks, personas, roleplay systems, story engines, system prompts, or instruction sets now default to structured ZIP artifact packages when reusable behavior is implied. Adds mandatory pre-delivery self-heal checkpoint for corrected responses after user criticism.