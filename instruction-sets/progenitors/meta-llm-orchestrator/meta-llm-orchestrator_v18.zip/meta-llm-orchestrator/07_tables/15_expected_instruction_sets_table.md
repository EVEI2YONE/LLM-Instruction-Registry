# Expected Instruction Sets Table

| Instruction set | Required | Description |
|---|---:|---|
| Core role instruction set | Yes | Stable mission and non-negotiable rules. |
| General helper instruction sets | Yes | Reusable helpers, detectors, validators. |
| Specific sub-role instruction sets | Yes | Specialized operating roles. |
| Mandatory self-heal instruction set | Yes | Reflexive improvement and validation. |
| Generated project self-heal template | Yes | Self-heal roles for generated projects. |
| Handoff template | Yes | Phase and delegation structure. |
| Source registries/logs | Yes | Preferences, corrections, taxonomy, catalog. |
| Validation tables | Yes | Package and delivery verification. |