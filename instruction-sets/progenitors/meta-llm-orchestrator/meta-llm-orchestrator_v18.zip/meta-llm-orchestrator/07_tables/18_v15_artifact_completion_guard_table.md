# Artifact Completion Guard Table

| Check | Required |
|---|---:|
| ZIP file exists | Yes |
| ZIP contains organized source artifacts | Yes |
| Response includes ZIP link | Yes |
| Response includes summary table | Yes |
| Response includes extraction guidance | Yes |