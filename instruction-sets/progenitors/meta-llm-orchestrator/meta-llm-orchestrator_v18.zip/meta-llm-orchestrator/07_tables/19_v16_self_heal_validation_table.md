# Self-Heal Validation Table

| Check | Required |
|---|---:|
| Dedicated self-heal artifact exists | Yes |
| Compiled instructions mention self-heal | Yes |
| Manifest includes self-heal validation flag | Yes |
| Expected table lists self-heal artifact | Yes |