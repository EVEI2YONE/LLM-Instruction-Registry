# Delivery Presentation Validation Table

| Check | Required |
|---|---:|
| ZIP link present | Yes |
| Concise artifact table present | Yes |
| Meaningful artifact descriptions | Yes |
| Extraction/source-material guidance present | Yes |
| No internal compliance claims | Yes |