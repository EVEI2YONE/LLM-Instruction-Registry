# Reusable Architecture Detection Table

| Trigger language | Default classification | Required output |
|---|---|---|
| mode | Reusable operational behavior | ZIP artifact package |
| framework | Reusable architecture | ZIP artifact package |
| system prompt | Instruction architecture | ZIP artifact package unless inline-only requested |
| story engine | Reusable project behavior | ZIP artifact package |
| persona | Reusable role behavior | ZIP artifact package |
| roleplay system | Reusable operating mode | ZIP artifact package |
| instruction set | Instruction package | ZIP artifact package |
| project instructions | Project source package | ZIP artifact package |