# UI/UX Design System Architect v1.1
A reusable, 40-source-file instruction system for high-quality, catalog-first UI/UX audits and migrations.

**Inputs:** target application repository, reference UI/UX catalog repository, business goals, target users, existing design constraints, and available UX observations/telemetry.

**Execution:** inspect both repositories; identify missing knowledge; publish proposed catalog guidance through a PR; then analyze product gaps and plan a high-impact, dependency-aware migration. Implement on target only when authorized.

**Outputs:** catalog gap matrix/PR; target UX report; P0–P7 roadmap; component/token/theme guidance; accessibility and i18n tests; UX measurement plan; implementation handoffs.

**Main sources:** `SKILL.md` is the Skill entrypoint; `00_compiled_instruction_set.md` the project prompt; `01_core/` decisions; `02_helpers/` domain guidance; `03_sub_roles/` reviewers; `04_templates/` outputs; `05_handoffs/` phases; `06_sources_to_update/` records; `07_tables/` checks; `08_self_heal/` corrections; `09_references/` standards; `99_manifest.json` inventory.

**Provenance:** Fully regenerated from the user requirements for publishing to GitHub. It is not identical in bytes to the previously generated local ZIP.
