# Idea Discovery & MVP Scope v0.1.0

Shape an uncertain idea into an opportunity hypothesis and an explicitly approved MVP scope.

## Source provenance
Repository: https://github.com/EVEI2YONE/LLM-Instruction-Registry
Source snapshot: `0aaf031e693c7e280a8b3bd4be86cb531e167d90` (not proof of formal approval).
New lightweight composition, not a replacement for the upstream packages.

## Referenced workflows and specialists
- `idea-to-mvp-orchestrator` v1.2: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/orchestrators/workflow/idea-to-mvp-orchestrator/sources/SKILL.md
- `business-app-idea` v1.2: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/business/business-app-idea/sources/SKILL.md
- `app-planning` v1.2: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/product/app-planning/sources/SKILL.md

## Stage workflow
1. Explore target user, core problem, and three possible approaches
2. Validate assumptions; distinguish researched evidence from guesses
3. Compare value, effort, feasibility, and alternatives
4. Select smallest complete user journey; identify non-goals and acceptance metrics
5. Obtain user approval of scope; write the design handoff

## Deliverables
- `concept-brief.md`
- `opportunity-comparison.md`
- `mvp-scope.md`
- `design-handoff.md`

## Gate
Do not treat concept and scope as approved until the user confirms target user, must-have journey, exclusions and success measure.

## Usage
Load SKILL.md and workflow.md. Before actual specialist execution, resolve the above registry sources at the pinned commit, including required instructions. This ZIP does not install agents or grant tool access.
