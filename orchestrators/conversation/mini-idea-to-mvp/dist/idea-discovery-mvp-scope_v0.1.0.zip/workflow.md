# Idea Discovery & MVP Scope workflow

Shape an uncertain idea into an opportunity hypothesis and an explicitly approved MVP scope.

## Ordered stages
1. Explore target user, core problem, and three possible approaches
2. Validate assumptions; distinguish researched evidence from guesses
3. Compare value, effort, feasibility, and alternatives
4. Select smallest complete user journey; identify non-goals and acceptance metrics
5. Obtain user approval of scope; write the design handoff

## Required handoff outputs
- `concept-brief.md`
- `opportunity-comparison.md`
- `mvp-scope.md`
- `design-handoff.md`

## Acceptance gate
Do not treat concept and scope as approved until the user confirms target user, must-have journey, exclusions and success measure.

## Shared conversation rules
- Ask at most one essential question; favor concrete useful artifacts.
- Maintain visible phase/decisions/scope/evidence/next-owner ledger.
- Never invent tool access, agent execution, runtime, approval, test results, merge or deployment.
- Resolve actual upstream SKILL.md, manifest and required transitive sections at pinned source revision before specialist work; otherwise mark BLOCKED_INSTRUCTIONS.
- Use sequential specialist fallback if no verified authorized child runner exists.
- Give 2-3 options when exploring, recommend a default, preserve user choices and non-goals.
- Distinguish PROPOSED, PROVISIONAL, BLOCKED and VERIFIED; never silently expand scope.
- Human approval is required for investment, merge, production deployment or irreversible changes.
