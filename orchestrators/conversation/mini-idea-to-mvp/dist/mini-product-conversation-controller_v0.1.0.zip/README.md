# Mini Product Conversation Controller v0.1.0

Route one conversation among discovery, visual studio and builder while tracking decisions and verified handoffs.

## Source provenance
Repository: https://github.com/EVEI2YONE/LLM-Instruction-Registry
Source snapshot: `0aaf031e693c7e280a8b3bd4be86cb531e167d90` (not proof of formal approval).
New lightweight composition, not a replacement for the upstream packages.

## Referenced workflows and specialists
- `product-conversation-orchestrator` v1.4: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/orchestrators/conversation/product-conversation-orchestrator/sources/SKILL.md
- `product-lifecycle-orchestrator` v1.1: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/orchestrators/primary/product-lifecycle-orchestrator/sources/SKILL.md

## Stage workflow
1. Interpret intent and reconcile workflow ledger
2. Route uncertain concept to discovery; approved scope to visual studio; approved visuals to build
3. Load pinned relevant upstream instructions and their manifest section closure
4. Delegate only to verified authorized child runners; otherwise execute sequential bounded specialist passes
5. Preserve outputs, approvals, evidence and handoff state without silently changing scope
6. Report current phase, blockers, progress and next owner

## Deliverables
- `workflow-ledger.md`
- `phase-handoff.md`

## Gate
Honor human gates, evidence and actual runtime capabilities.

## Usage
Load SKILL.md and workflow.md. Before actual specialist execution, resolve the above registry sources at the pinned commit, including required instructions. This ZIP does not install agents or grant tool access.
