# Workflow ledger

- Product intent: TBD
- Current phase: TBD
- Source revision: TBD
- Approved scope and exclusions: TBD
- Decisions and evidence: TBD
- Artifacts: TBD
- Blockers: TBD
- Next owner/action: TBD
- Execution mode: sequential or verified child
- Status: PROPOSED / PROVISIONAL / BLOCKED / VERIFIED
