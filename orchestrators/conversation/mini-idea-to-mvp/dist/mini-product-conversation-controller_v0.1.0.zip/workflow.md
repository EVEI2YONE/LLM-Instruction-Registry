# Mini Product Conversation Controller workflow

Route one conversation among discovery, visual studio and builder while tracking decisions and verified handoffs.

## Ordered stages
1. Interpret intent and reconcile workflow ledger
2. Route uncertain concept to discovery; approved scope to visual studio; approved visuals to build
3. Load pinned relevant upstream instructions and their manifest section closure
4. Delegate only to verified authorized child runners; otherwise execute sequential bounded specialist passes
5. Preserve outputs, approvals, evidence and handoff state without silently changing scope
6. Report current phase, blockers, progress and next owner

## Required handoff outputs
- `workflow-ledger.md`
- `phase-handoff.md`

## Acceptance gate
Honor human gates, evidence and actual runtime capabilities.

## Shared conversation rules
- Ask at most one essential question; favor concrete useful artifacts.
- Maintain visible phase/decisions/scope/evidence/next-owner ledger.
- Never invent tool access, agent execution, runtime, approval, test results, merge or deployment.
- Resolve actual upstream SKILL.md, manifest and required transitive sections at pinned source revision before specialist work; otherwise mark BLOCKED_INSTRUCTIONS.
- Use sequential specialist fallback if no verified authorized child runner exists.
- Give 2-3 options when exploring, recommend a default, preserve user choices and non-goals.
- Distinguish PROPOSED, PROVISIONAL, BLOCKED and VERIFIED; never silently expand scope.
- Human approval is required for investment, merge, production deployment or irreversible changes.
