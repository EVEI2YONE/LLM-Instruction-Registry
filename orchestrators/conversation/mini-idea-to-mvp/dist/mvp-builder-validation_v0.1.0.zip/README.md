# MVP Builder & Validation v0.1.0

Build one working end-to-end MVP slice, validate its behavior and compare implementation against approved visuals.

## Source provenance
Repository: https://github.com/EVEI2YONE/LLM-Instruction-Registry
Source snapshot: `0aaf031e693c7e280a8b3bd4be86cb531e167d90` (not proof of formal approval).
New lightweight composition, not a replacement for the upstream packages.

## Referenced workflows and specialists
- `software-delivery-lifecycle` v1.2: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/orchestrators/workflow/software-delivery-lifecycle/sources/SKILL.md
- `frontend-engineering-specialist` v1.2: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/engineering/frontend-engineering-specialist/sources/SKILL.md
- `backend-engineering-specialist` v1.2: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/engineering/backend-engineering-specialist/sources/SKILL.md
- `test-automation-specialist` v1.1: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/quality/test-automation-specialist/sources/SKILL.md
- `pragmatic-pr-reviewer` v1.1: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/quality/pragmatic-pr-reviewer/sources/SKILL.md

## Stage workflow
1. Check approved scope, design contracts, stack and repo access
2. Plan thin vertical slices around a demonstrable happy path
3. Implement real interactions with conditional backend/API support
4. Run observable tests and inspect logs, responsive states and keyboard interactions
5. Compare implemented screens to approved design; document visual defects
6. Prepare demo, release evidence, unresolved risks and next iteration

## Deliverables
- `implementation-plan.md`
- `acceptance-matrix.md`
- `test-evidence.md`
- `visual-qa.md`
- `demo-and-release-notes.md`

## Gate
Do not claim working/tested/released without observed evidence; production deployment requires separate human approval.

## Usage
Load SKILL.md and workflow.md. Before actual specialist execution, resolve the above registry sources at the pinned commit, including required instructions. This ZIP does not install agents or grant tool access.
