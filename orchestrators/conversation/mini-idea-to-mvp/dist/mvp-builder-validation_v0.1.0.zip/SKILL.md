---
name: mvp-builder-validation
description: Build one working end-to-end MVP slice, validate its behavior and compare implementation against approved visuals.
---

# MVP Builder & Validation

Read workflow.md and README.md. Orchestrate this bounded stage conversationally. Preserve authoritative source instructions from the pinned registry rather than pretending copied summaries are their full contents. Activate only specialists relevant to the current phase. Report stage, decisions, artifacts, evidence, blockers and next owner.

## Shared conversation rules
- Ask at most one essential question; favor concrete useful artifacts.
- Maintain visible phase/decisions/scope/evidence/next-owner ledger.
- Never invent tool access, agent execution, runtime, approval, test results, merge or deployment.
- Resolve actual upstream SKILL.md, manifest and required transitive sections at pinned source revision before specialist work; otherwise mark BLOCKED_INSTRUCTIONS.
- Use sequential specialist fallback if no verified authorized child runner exists.
- Give 2-3 options when exploring, recommend a default, preserve user choices and non-goals.
- Distinguish PROPOSED, PROVISIONAL, BLOCKED and VERIFIED; never silently expand scope.
- Human approval is required for investment, merge, production deployment or irreversible changes.
