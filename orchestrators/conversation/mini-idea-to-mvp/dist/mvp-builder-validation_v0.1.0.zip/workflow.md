# MVP Builder & Validation workflow

Build one working end-to-end MVP slice, validate its behavior and compare implementation against approved visuals.

## Ordered stages
1. Check approved scope, design contracts, stack and repo access
2. Plan thin vertical slices around a demonstrable happy path
3. Implement real interactions with conditional backend/API support
4. Run observable tests and inspect logs, responsive states and keyboard interactions
5. Compare implemented screens to approved design; document visual defects
6. Prepare demo, release evidence, unresolved risks and next iteration

## Required handoff outputs
- `implementation-plan.md`
- `acceptance-matrix.md`
- `test-evidence.md`
- `visual-qa.md`
- `demo-and-release-notes.md`

## Acceptance gate
Do not claim working/tested/released without observed evidence; production deployment requires separate human approval.

## Shared conversation rules
- Ask at most one essential question; favor concrete useful artifacts.
- Maintain visible phase/decisions/scope/evidence/next-owner ledger.
- Never invent tool access, agent execution, runtime, approval, test results, merge or deployment.
- Resolve actual upstream SKILL.md, manifest and required transitive sections at pinned source revision before specialist work; otherwise mark BLOCKED_INSTRUCTIONS.
- Use sequential specialist fallback if no verified authorized child runner exists.
- Give 2-3 options when exploring, recommend a default, preserve user choices and non-goals.
- Distinguish PROPOSED, PROVISIONAL, BLOCKED and VERIFIED; never silently expand scope.
- Human approval is required for investment, merge, production deployment or irreversible changes.
