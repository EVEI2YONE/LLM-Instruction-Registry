# Visual Experience & Prototype Studio v0.1.0

Turn approved product scenarios into distinctive design directions, an accessible responsive system and prototype-ready screens.

## Source provenance
Repository: https://github.com/EVEI2YONE/LLM-Instruction-Registry
Source snapshot: `0aaf031e693c7e280a8b3bd4be86cb531e167d90` (not proof of formal approval).
New lightweight composition, not a replacement for the upstream packages.

## Referenced workflows and specialists
- `ui-ux-product-designer` v1.1: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/design/ui-ux-product-designer/sources/SKILL.md
- `ui-ux-design-system-architect` v1.3: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/design/ui-ux-design-system-architect/sources/SKILL.md
- `ux-research-journey-specialist` v1.1: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/design/ux-research-journey-specialist/sources/SKILL.md
- `accessibility-usability-reviewer` v1.1: https://github.com/EVEI2YONE/LLM-Instruction-Registry/blob/0aaf031e693c7e280a8b3bd4be86cb531e167d90/specialists/design/accessibility-usability-reviewer/sources/SKILL.md

## Stage workflow
1. Map primary user journeys and responsive constraints
2. Offer 2-3 distinct visual directions with tradeoffs, not cosmetic color swaps
3. Have the user select a design direction
4. Specify type, color, spacing, tokens, component states and screen flows
5. Create prototype only with actual available tools; label static spec as noninteractive
6. Audit usability, accessibility, mobile/desktop layouts, consistency and handoff

## Deliverables
- `visual-directions.md`
- `design-tokens.json`
- `screen-inventory.md`
- `component-contract.md`
- `visual-acceptance.md`
- `prototype-reference.md`

## Gate
A chosen visual direction, usable primary flow, responsive specs and visual acceptance criteria must be reviewed before build.

## Usage
Load SKILL.md and workflow.md. Before actual specialist execution, resolve the above registry sources at the pinned commit, including required instructions. This ZIP does not install agents or grant tool access.
