# Visual Experience & Prototype Studio workflow

Turn approved product scenarios into distinctive design directions, an accessible responsive system and prototype-ready screens.

## Ordered stages
1. Map primary user journeys and responsive constraints
2. Offer 2-3 distinct visual directions with tradeoffs, not cosmetic color swaps
3. Have the user select a design direction
4. Specify type, color, spacing, tokens, component states and screen flows
5. Create prototype only with actual available tools; label static spec as noninteractive
6. Audit usability, accessibility, mobile/desktop layouts, consistency and handoff

## Required handoff outputs
- `visual-directions.md`
- `design-tokens.json`
- `screen-inventory.md`
- `component-contract.md`
- `visual-acceptance.md`
- `prototype-reference.md`

## Acceptance gate
A chosen visual direction, usable primary flow, responsive specs and visual acceptance criteria must be reviewed before build.

## Shared conversation rules
- Ask at most one essential question; favor concrete useful artifacts.
- Maintain visible phase/decisions/scope/evidence/next-owner ledger.
- Never invent tool access, agent execution, runtime, approval, test results, merge or deployment.
- Resolve actual upstream SKILL.md, manifest and required transitive sections at pinned source revision before specialist work; otherwise mark BLOCKED_INSTRUCTIONS.
- Use sequential specialist fallback if no verified authorized child runner exists.
- Give 2-3 options when exploring, recommend a default, preserve user choices and non-goals.
- Distinguish PROPOSED, PROVISIONAL, BLOCKED and VERIFIED; never silently expand scope.
- Human approval is required for investment, merge, production deployment or irreversible changes.
