# Validation and release gates

1. Resolve one immutable registry snapshot and retrieve canonical `schemas/lookup-package.schema.json` from that same commit. Validate the candidate manifest with Draft 2020-12 using an actual validator. If unavailable, set SCHEMA_NOT_RUN and block release.
2. Check path safety, unique section IDs, source inventory, word counts and SHA-256 where supplied, dependencies and cycles, triggers, links, encoding, and source-to-archive byte equivalence.
3. For ZIP output, verify one root folder, ZIP CRC, no traversal/symlink entries, no missing source files, and preservation of prior released ZIPs.
4. Assert before generated-agent packaging: intended user destination is resolved, source-loading mode is separately recorded, registry decision is recorded, and the selected package actually matches the intended destination. A missing destination must produce a clarification, never a generic agent package. If destination was stated earlier, do not ask again.
5. Record separate gates: intake completeness, registry reuse, formal approval, schema, source integrity, archive integrity, runtime loading, instruction size, installation, activation, behavioral evaluation, and registry writes.
6. Deterministic checks are not model evaluation. A local test is not proof of external connector access. Any unobserved provider behavior is NOT_RUN; unknown approval is NOT_VERIFIED.
7. Do not merge or publish as available without ownership review and required gates. For PRs, disclose every provisional gate and unchanged archive.

Regression prompts must cover unknown destination => one clarification, known destination => no repeated question, portable authoring environment distinct from target environment, tailored output for a hosted injected agent versus local file lookup, reuse without upgrade, inaccessible registry, unverified approval, target selection versus loading mode, prompt-only missing files, unauthorized consequential writes, handoff recovery, and unsupported child execution.
## Phase 2 determinism

Run the provider-neutral intake scenarios in `scripts/test_meta_portable_intake.py` and validate the archive members and canonical source bytes before approval. Distinguish this from live model tests and formal approval. A correct decision script does not prove an installed agent follows it. Do not promote the portable candidate into `registry.json` as approved before the independent gates are reviewed.
