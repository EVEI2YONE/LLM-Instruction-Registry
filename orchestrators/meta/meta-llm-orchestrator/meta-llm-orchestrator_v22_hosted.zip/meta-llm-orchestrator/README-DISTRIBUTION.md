# Meta-LLM Orchestrator v22 Hosted

Inject `HOSTED_INSTRUCTIONS.md` (the complete assembled agent instruction payload) through a supported hosting instruction mechanism. Do not assume scripts or lockfiles exist in the chat runtime. The external knowledge and agent registry are source references, not bundled complete knowledge repositories. If the host truncates instructions, do not claim successful installation.
