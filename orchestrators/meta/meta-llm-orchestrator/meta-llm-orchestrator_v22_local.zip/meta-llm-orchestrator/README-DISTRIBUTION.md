# Meta-LLM Orchestrator v22 Local

Start at `SKILL.md`. Use `manifest.json` and `sections/` for lookup-first loading. The scripts are provided as source but execute only if locally authorized. Resolve repositories using `references/source-locations.json` and record pin/permission evidence; never broaden least-privilege access.
