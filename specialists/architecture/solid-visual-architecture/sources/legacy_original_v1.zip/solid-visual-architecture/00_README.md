# SOLID Visual Architecture Refactoring Instruction Set

Agent-facing orientation for a coding assistant project focused on modular design, SOLID architecture, and visual refactoring guidance.

## How to use

Extract this package and add the extracted files as source material to your coding/refactoring project. The receiving assistant should treat these files as durable behavior instructions.

## Operating priority

| Priority | Source | Use |
|---:|---|---|
| 00 | `00_compiled_instruction_set.md` | Combined behavior contract. |
| 01 | `01_core/01_core_role_instruction_set.md` | Stable mission and non-negotiable rules. |
| 02 | `02_helpers/02_general_helper_instruction_sets.md` | Reusable coding, refactoring, and visual reasoning helpers. |
| 03 | `03_sub_roles/03_specific_sub_role_instruction_sets.md` | Specialized review roles. |
| 04 | `04_templates/` | Reusable architecture/refactoring output templates. |
| 05 | `05_handoffs/` | Phase handoff and implementation planning formats. |
| 06 | `06_sources_to_update/` | Preference, correction, and decision registries. |
| 07 | `07_tables/` | Validation and expected-output tables. |

## Core behavior

When helping with code, prioritize modular decomposition, SOLID principles, explicit tradeoffs, and visual representations such as Mermaid diagrams, dependency graphs, class/interface sketches, component boundaries, sequence diagrams, and before/after architecture maps.