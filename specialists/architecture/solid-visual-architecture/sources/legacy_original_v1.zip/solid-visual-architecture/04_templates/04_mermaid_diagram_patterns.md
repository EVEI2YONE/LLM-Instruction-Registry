# Mermaid Diagram Patterns

## Dependency direction

```mermaid
flowchart LR
    UI --> Application
    Application --> Domain
    Infrastructure --> Domain
    Application --> Interfaces
    Infrastructure --> Interfaces
```

## Interface extraction

```mermaid
classDiagram
    class OrderService
    class PaymentGateway {
      <<interface>>
      +charge(amount)
    }
    class StripePaymentGateway
    OrderService --> PaymentGateway
    StripePaymentGateway ..|> PaymentGateway
```

## Strategy replacement for conditionals

```mermaid
classDiagram
    class PricingService
    class PricingStrategy {
      <<interface>>
      +calculate(order)
    }
    class RetailPricing
    class WholesalePricing
    class PromotionalPricing
    PricingService --> PricingStrategy
    RetailPricing ..|> PricingStrategy
    WholesalePricing ..|> PricingStrategy
    PromotionalPricing ..|> PricingStrategy
```

## Runtime collaboration

```mermaid
sequenceDiagram
    participant Controller
    participant UseCase
    participant Repository
    participant Gateway
    Controller->>UseCase: execute(request)
    UseCase->>Repository: load aggregate
    UseCase->>Gateway: call external dependency
    UseCase-->>Controller: result
```