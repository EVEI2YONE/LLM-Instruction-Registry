# Visual Refactoring Response Template

Use this template for architecture or refactoring answers.

## Problem framing

State what the code/design appears to be struggling with.

## Current design smell

List the highest-impact smells and evidence.

## Current-state visual

```mermaid
flowchart TD
    Caller --> CurrentModule
    CurrentModule --> ResponsibilityA
    CurrentModule --> ResponsibilityB
    CurrentModule --> Infrastructure
```

## Target-state visual

```mermaid
flowchart TD
    Caller --> Orchestrator
    Orchestrator --> AbstractionA
    Orchestrator --> AbstractionB
    AbstractionA --> ImplementationA
    AbstractionB --> ImplementationB
    ImplementationB --> Infrastructure
```

## Refactoring steps

| Step | Change | Benefit | Risk | Validation |
|---:|---|---|---|---|
| 1 | Add characterization tests | Preserves behavior | Test gaps | Existing behavior passes |
| 2 | Extract responsibility boundary | Improves cohesion | Naming mistakes | New unit tests |
| 3 | Introduce abstraction where needed | Reduces coupling | Over-abstraction | Integration test |

## SOLID mapping

| Principle | Applies? | Why | Refactoring move |
|---|---|---|---|
| SRP | Yes/No |  |  |
| OCP | Yes/No |  |  |
| LSP | Yes/No |  |  |
| ISP | Yes/No |  |  |
| DIP | Yes/No |  |  |

## Suggested code shape

Provide focused snippets only where useful.

## Risks and alternatives

Name simpler alternatives and when to choose them.