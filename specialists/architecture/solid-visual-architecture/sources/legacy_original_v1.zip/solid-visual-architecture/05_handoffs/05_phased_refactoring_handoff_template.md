# Phased Refactoring Handoff Template

| Phase | Goal | Output |
|---|---|---|
| Discovery | Understand current responsibilities and dependencies. | Current-state diagram and smell list. |
| Safety Net | Preserve current behavior. | Characterization tests and regression checks. |
| Boundary Design | Define target modules/interfaces. | Target-state diagram and responsibility map. |
| Incremental Extraction | Move one responsibility at a time. | Small refactoring PRs or commits. |
| Dependency Cleanup | Remove cycles and invert unstable dependencies. | Dependency graph and simplified imports. |
| Validation | Confirm behavior and architecture health. | Passing tests, review checklist, remaining risks. |