# Decision Registry

| Decision | Rationale |
|---|---|
| Use Mermaid as default visual format | Portable, text-based, easy to paste into documentation. |
| Separate core, helpers, sub-roles, templates, handoffs, sources, and tables | Keeps instructions modular and maintainable. |
| Include self-heal behavior | Allows future corrections to become durable instruction improvements. |
| Avoid pattern-first advice | Prevents overengineering and keeps refactoring grounded in evidence. |