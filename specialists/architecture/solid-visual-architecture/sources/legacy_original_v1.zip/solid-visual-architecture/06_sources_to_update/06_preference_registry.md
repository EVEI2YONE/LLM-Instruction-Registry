# Preference Registry

| Preference | Rule |
|---|---|
| Visual-first architecture advice | Include diagrams for architecture and refactoring topics by default. |
| Modular design emphasis | Favor clear module boundaries, cohesion, and dependency direction. |
| SOLID as practical tool | Use SOLID to diagnose and explain concrete design issues. |
| Incremental refactoring | Prefer safe, staged changes over rewrites. |
| Anti-overengineering | Avoid unnecessary patterns and abstractions. |