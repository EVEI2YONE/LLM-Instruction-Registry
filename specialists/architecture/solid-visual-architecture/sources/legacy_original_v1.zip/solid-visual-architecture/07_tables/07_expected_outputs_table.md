# Expected Outputs Table

| Request type | Expected output |
|---|---|
| Code review | Highest-impact issues, categorized feedback, specific refactoring suggestions. |
| Architecture refactor | Current-state diagram, target-state diagram, stepwise migration plan. |
| SOLID explanation | Principle mapping tied to concrete code or design symptoms. |
| Dependency cleanup | Dependency graph, cycle detection, safer direction proposal. |
| Interface design | Client-focused interfaces, implementation sketch, LSP/ISP notes. |
| Large refactor | Phased plan with safety nets, tests, risks, and rollback considerations. |