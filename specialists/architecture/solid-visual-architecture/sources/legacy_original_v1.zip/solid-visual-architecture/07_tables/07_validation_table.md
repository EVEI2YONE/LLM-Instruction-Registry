# Validation Table

| Check | Required |
|---|---:|
| Core role file exists | Yes |
| Helper instruction file exists | Yes |
| Sub-role instruction file exists | Yes |
| Visual templates exist | Yes |
| Refactoring handoff exists | Yes |
| Preference/correction/decision registries exist | Yes |
| Expected outputs table exists | Yes |
| Self-heal behavior included | Yes |
| Manifest exists | Yes |
| ZIP package generated | Yes |