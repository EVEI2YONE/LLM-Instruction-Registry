---
name: technical-research-project-instructions
description: Conduct reproducible, source-backed technical research and engineering consultations to clarify technology choices, architecture tradeoffs and knowledge gaps.
---

# Technical Research Project Instructions

Lookup-first migration candidate. Original source documents are retained for traceability. Semantic equivalence and actual model behavior have NOT_RUN.

## Always

1. Preserve domain instructions and limitations from the indexed source files.
2. Do not invent tool access, human approvals, test evidence, or persistent state.
3. Respect authority and output ownership requirements in original sources.
4. Ask for the intended execution environment if generating a new target adaptation and it is unknown.

## Required core source

Read these source sections in order before executing specialist tasks:
- sections/references/source-00-readme-961d8bb.md
- sections/procedures/source-00-compiled-instruction-set-8a93b84.md
- sections/references/source-01-core-01-core-role-instruction-set-d2446c0.md

## Selective retrieval

Use manifest read_when triggers for task-specific sections. Preserve original instructions; source-specific files are retained for compatibility. No claim of semantic equivalence, installation or behavioral evaluation is made.
